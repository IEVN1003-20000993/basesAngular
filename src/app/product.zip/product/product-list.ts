export interface IProducto {
    productoId:number;
    Modelo:string;
    Descripcion:string;
    Year:string;
    Precio:number;
    Marca:string;
    Color:string;
    imagenUrl:string;
}